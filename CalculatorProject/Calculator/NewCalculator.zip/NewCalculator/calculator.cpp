#include "calculator.h"

Calculator::Calculator(QObject *parent) : QObject(parent)
{

}
